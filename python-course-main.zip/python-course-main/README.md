# python-course
This is the basics of Python which I am going to upload it day wise
